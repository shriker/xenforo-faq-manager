<?php

class Iversia_FAQ_Search_DataHandler_Question extends XenForo_Search_DataHandler_Abstract
{

}
